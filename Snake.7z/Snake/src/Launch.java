
public class Launch {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		MainWindow q = new MainWindow();
	}

}
